const SAMPLES = {
  arith: `int x = 5;\nint y = 10;\nint z = x + y * 2;\nint result = z / 3;`,
  ifelse: `int x = 5;\nint y = 10;\nif (x < y) {\n  x = x + 1;\n} else {\n  y = y - 1;\n}`,
  loop: `int i = 0;\nint sum = 0;\nwhile (i < 5) {\n  sum = sum + i;\n  i = i + 1;\n}`,
  errors: `int x = 5;\nint x = 10;\ny = x + 1;\nint z;\nz = z + w;`,
  complex: `int a = 4;\nint b = 2;\nint c = a * b + 10;\nint d = c / 2;\nif (d > 5) {\n  c = c - d;\n}\nwhile (a > 0) {\n  a = a - 1;\n}`
};

let currentPhase = -1;
let state = {};

function loadSample(key, btn) {
  document.getElementById('src').value = SAMPLES[key];
  document.querySelectorAll('.sample-tab').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  updateLineNums();
  resetAll();
}

function updateLineNums() {
  const lines = document.getElementById('src').value.split('\n').length;
  document.getElementById('line-nums').innerHTML = Array.from({length: lines}, (_,i) => i+1).join('\n');
}

function setStatus(text, cls) {
  const el = document.getElementById('status-pill');
  el.textContent = '● ' + text;
  el.className = 'status-pill ' + (cls||'');
}

function setPhaseCls(i, cls) {
  const el = document.getElementById('ph'+i);
  el.className = 'phase-node ' + (cls||'');
}

function resetAll() {
  currentPhase = -1;
  state = {};
  for (let i = 0; i < 6; i++) setPhaseCls(i, '');
  ['lex','parse','sem','ir','opt','code'].forEach(id => {
    document.getElementById('out-'+id).innerHTML = '<span class="placeholder">Waiting for compilation...</span>';
    const b = document.getElementById('badge-'+id);
    if (b) b.style.display = 'none';
  });
  setStatus('idle');
}

function runAll() {
  resetAll();
  for (let i = 0; i < 6; i++) {
    (i => setTimeout(() => runPhase(i), i * 300))(i);
  }
}

function runStep() {
  currentPhase++;
  if (currentPhase >= 6) { currentPhase = 5; return; }
  runPhase(currentPhase);
}

function runPhase(n) {
  if (n === 0) state = {};
  setPhaseCls(n, 'active');
  setStatus('running phase ' + (n+1) + '...', 'running');

  const ids = ['lex','parse','sem','ir','opt','code'];
  document.getElementById('out-'+ids[n]).innerHTML = '<span class="placeholder">⟳ processing...</span>';

  setTimeout(() => {
    try {
      const src = document.getElementById('src').value;
      const fns = [doLex, doParse, doSem, doIR, doOpt, doCodeGen];
      fns[n](src, state);
      const hasErr = state['err'+n];
      setPhaseCls(n, hasErr ? 'err' : 'done');
      setStatus(hasErr ? 'phase '+(n+1)+': errors found' : 'phase '+(n+1)+' complete', hasErr ? 'error' : 'done');
    } catch(e) {
      setPhaseCls(n, 'err');
      setStatus('phase '+(n+1)+' failed', 'error');
      console.error(e);
    }
  }, 100);
}

/* === UTILS === */
const KEYWORDS = new Set(['int','float','if','else','while','return','void','string','char','bool']);

function tokenize(src) {
  const tokens = [];
  let i = 0;
  while (i < src.length) {
    if (/\s/.test(src[i])) { i++; continue; }
    if (src[i]==='/' && src[i+1]==='/') { while(i<src.length && src[i]!=='\n') i++; continue; }
    if (src[i]==='"') {
      let s = '"'; i++;
      while (i < src.length && src[i] !== '"') s += src[i++];
      s += '"'; i++;
      tokens.push({type:'STRING', val:s}); continue;
    }
    if (/[a-zA-Z_]/.test(src[i])) {
      let s = '';
      while (i < src.length && /[a-zA-Z0-9_]/.test(src[i])) s += src[i++];
      tokens.push({type: KEYWORDS.has(s) ? 'KEYWORD' : 'IDENT', val:s}); continue;
    }
    if (/[0-9]/.test(src[i])) {
      let s = '';
      while (i < src.length && /[0-9.]/.test(src[i])) s += src[i++];
      tokens.push({type:'NUM', val:s}); continue;
    }
    const two = src.slice(i,i+2);
    if (['==','!=','<=','>=','&&','||','++','--'].includes(two)) {
      tokens.push({type:'OP', val:two}); i+=2; continue;
    }
    if ('+-*/=<>!'.includes(src[i])) { tokens.push({type:'OP', val:src[i]}); i++; continue; }
    if ('(){};,'.includes(src[i])) { tokens.push({type:'PUNCT', val:src[i]}); i++; continue; }
    tokens.push({type:'UNKNOWN', val:src[i]}); i++;
  }
  return tokens;
}

function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

/* === PHASE 1: LEXER === */
function doLex(src, state) {
  const tokens = tokenize(src);
  state.tokens = tokens;

  const tokenCounts = {};
  tokens.forEach(t => { tokenCounts[t.type] = (tokenCounts[t.type]||0)+1; });

  let html = `<div class="fade-in">`;
  html += `<div style="margin-bottom:10px;color:var(--green);font-size:11px">✓ Tokenization complete — ${tokens.length} tokens generated</div>`;
  html += `<div class="token-area">`;
  tokens.forEach(t => {
    html += `<span class="tok tok-${t.type}" title="${t.type}">${esc(t.val)}</span>`;
  });
  html += `</div>`;
  html += `<div style="margin-top:12px;padding-top:10px;border-top:1px solid var(--border)">`;
  html += `<div style="color:var(--text3);font-size:10px;margin-bottom:6px;text-transform:uppercase;letter-spacing:0.5px">Token Summary</div>`;
  html += `<table class="sym-table">`;
  html += `<tr><th>Type</th><th>Count</th><th>Example</th></tr>`;
  Object.entries(tokenCounts).forEach(([type, count]) => {
    const ex = tokens.find(t=>t.type===type)?.val||'';
    html += `<tr><td style="color:var(--purple)">${type}</td><td style="color:var(--cyan)">${count}</td><td style="color:var(--text2)">${esc(ex)}</td></tr>`;
  });
  html += `</table></div></div>`;

  document.getElementById('out-lex').innerHTML = html;
  const b = document.getElementById('badge-lex');
  b.textContent = tokens.length + ' tokens';
  b.style.display = '';
}

/* === PHASE 2: PARSER === */
function doParse(src, state) {
  const toks = state.tokens || tokenize(src);
  const lines = src.trim().split('\n');
  const ast = { node:'Program', children: lines.filter(l=>l.trim()).map(l=>parseLine(l.trim())) };
  state.ast = ast;

  let html = `<div class="fade-in">`;
  html += `<div style="margin-bottom:10px;color:var(--green);font-size:11px">✓ Parsing complete — AST constructed</div>`;
  html += `<div class="tree">${renderTree(ast,'',true)}</div>`;
  html += `</div>`;
  document.getElementById('out-parse').innerHTML = html;

  const b = document.getElementById('badge-parse');
  b.textContent = ast.children.length + ' stmts';
  b.style.display = '';
}

function parseLine(line) {
  const clean = line.replace(';','').trim();
  for (const kw of ['int','float','string','char','bool']) {
    if (clean.startsWith(kw+' ')) {
      const rest = clean.slice(kw.length+1);
      const eqIdx = rest.indexOf('=');
      const name = eqIdx>=0 ? rest.slice(0,eqIdx).trim() : rest.trim();
      const rhs  = eqIdx>=0 ? rest.slice(eqIdx+1).trim() : null;
      return { node:'VarDecl', children:[
        {node:'Type', val:kw},
        {node:'Identifier', val:name},
        ...(rhs ? [{node:'Init', children:[parseExpr(rhs)]}] : [])
      ]};
    }
  }
  if (clean.startsWith('if')) {
    const cond = clean.match(/\(([^)]+)\)/)?.[1]||'?';
    return { node:'IfStatement', children:[
      {node:'Condition', children:[parseExpr(cond)]},
      {node:'ThenBlock', val:'{ ... }'},
      ...(clean.includes('else') ? [{node:'ElseBlock', val:'{ ... }'}] : [])
    ]};
  }
  if (clean.startsWith('while')) {
    const cond = clean.match(/\(([^)]+)\)/)?.[1]||'?';
    return { node:'WhileStatement', children:[
      {node:'Condition', children:[parseExpr(cond)]},
      {node:'Body', val:'{ ... }'}
    ]};
  }
  if (clean.includes('=') && !clean.startsWith('{') && !clean.startsWith('}')) {
    const eqIdx = clean.indexOf('=');
    const lhs = clean.slice(0,eqIdx).trim();
    const rhs = clean.slice(eqIdx+1).trim();
    return { node:'Assignment', children:[
      {node:'LValue', val:lhs},
      {node:'RValue', children:[parseExpr(rhs)]}
    ]};
  }
  return { node:'Statement', val:clean||'{ }' };
}

function parseExpr(expr) {
  expr = expr.trim();
  for (const op of ['||','&&','==','!=','<=','>=','<','>','+','-']) {
    const idx = expr.lastIndexOf(op);
    if (idx > 0 && idx < expr.length - op.length) {
      return { node:'BinaryOp', val:op, children:[
        parseExpr(expr.slice(0,idx)),
        parseExpr(expr.slice(idx+op.length))
      ]};
    }
  }
  for (const op of ['*','/']) {
    const idx = expr.lastIndexOf(op);
    if (idx > 0) {
      return { node:'BinaryOp', val:op, children:[
        parseExpr(expr.slice(0,idx)),
        parseExpr(expr.slice(idx+1))
      ]};
    }
  }
  return { node:/^\d/.test(expr)?'NumberLiteral':'Identifier', val:expr };
}

function renderTree(node, prefix, last) {
  const c = last ? '└─ ' : '├─ ';
  const p = last ? '   ' : '│  ';
  let s = `<span class="tc">${esc(prefix)}${esc(c)}</span>`;
  s += `<span class="tn">${esc(node.node)}</span>`;
  if (node.val !== undefined) s += ` <span class="tl">"${esc(String(node.val))}"</span>`;
  s += '\n';
  if (node.children) {
    node.children.forEach((ch, i) => {
      s += renderTree(ch, prefix+p, i===node.children.length-1);
    });
  }
  return s;
}

/* === PHASE 3: SEMANTIC === */
function doSem(src, state) {
  const lines = src.trim().split('\n');
  const symTable = {};
  const errors = [], warnings = [], infos = [];

  lines.forEach((rawLine, li) => {
    const line = rawLine.trim().replace(';','');
    for (const kw of ['int','float','string','char','bool']) {
      if (line.startsWith(kw+' ')) {
        const rest = line.slice(kw.length+1);
        const name = rest.split('=')[0].trim();
        if (symTable[name]) {
          errors.push(`Line ${li+1}: Duplicate declaration of variable '${name}'`);
        } else {
          const hasInit = rest.includes('=');
          symTable[name] = { type:kw, initialized:hasInit, line:li+1 };
          infos.push(`Line ${li+1}: Declared '${name}' as ${kw}${hasInit?' (initialized)':''}`);
          if (!hasInit) warnings.push(`Line ${li+1}: Variable '${name}' declared but not initialized`);
          if (hasInit) {
            const rhs = rest.split('=')[1]||'';
            const used = rhs.match(/[a-zA-Z_]\w*/g)||[];
            used.filter(u=>!KEYWORDS.has(u)).forEach(u => {
              if (!symTable[u]) errors.push(`Line ${li+1}: Undefined variable '${u}' used in initializer`);
            });
          }
        }
        return;
      }
    }
    if (line.includes('=') && !line.startsWith('if') && !line.startsWith('while') && !line.startsWith('{') && !line.startsWith('}')) {
      const lhs = line.split('=')[0].trim();
      if (lhs && /^[a-zA-Z_]\w*$/.test(lhs) && !symTable[lhs]) {
        errors.push(`Line ${li+1}: Assignment to undeclared variable '${lhs}'`);
      }
    }
    const allIdents = rawLine.match(/[a-zA-Z_]\w*/g)||[];
    allIdents.filter(u=>!KEYWORDS.has(u)&&u!=='else').forEach(u => {
      if (!symTable[u] && !line.startsWith(u+' ') && line.includes(u)) {
        // covered above
      }
    });
  });

  state.symTable = symTable;
  state.err2 = errors.length > 0;

  let html = `<div class="fade-in">`;
  html += `<div style="margin-bottom:10px;color:${errors.length?'var(--red)':'var(--green)'};font-size:11px">`;
  html += errors.length ? `✗ ${errors.length} error(s) detected` : `✓ Semantic analysis passed`;
  html += `</div>`;

  html += `<div style="margin-bottom:12px">`;
  html += `<div style="color:var(--text3);font-size:10px;margin-bottom:6px;text-transform:uppercase;letter-spacing:0.5px">Symbol Table</div>`;
  html += `<table class="sym-table"><tr><th>Name</th><th>Type</th><th>Init</th><th>Ln</th></tr>`;
  Object.entries(symTable).forEach(([k,v]) => {
    html += `<tr>
      <td style="color:var(--cyan)">${esc(k)}</td>
      <td style="color:var(--purple)">${v.type}</td>
      <td>${v.initialized?'<span class="badge badge-ok">yes</span>':'<span class="badge badge-err">no</span>'}</td>
      <td style="color:var(--text3)">${v.line}</td>
    </tr>`;
  });
  html += `</table></div>`;

  html += `<div style="padding-top:8px;border-top:1px solid var(--border)">`;
  infos.forEach(m => { html += `<div class="info-line" style="font-size:11px">ℹ ${esc(m)}</div>`; });
  warnings.forEach(m => { html += `<div class="warn-line" style="font-size:11px">⚠ ${esc(m)}</div>`; });
  errors.forEach(m => { html += `<div class="err-line" style="font-size:11px">✗ ${esc(m)}</div>`; });
  html += `</div></div>`;

  document.getElementById('out-sem').innerHTML = html;
  const b = document.getElementById('badge-sem');
  b.textContent = errors.length ? errors.length+' errors' : 'no errors';
  b.className = 'badge ' + (errors.length ? 'badge-err' : 'badge-ok');
  b.style.display = '';
}

/* === PHASE 4: IR GEN === */
function doIR(src, state) {
  const lines = src.trim().split('\n');
  const ir = [];
  let tc = 1;
  const tmp = () => `t${tc++}`;

  lines.forEach(rawLine => {
    const line = rawLine.trim().replace(';','');
    for (const kw of ['int','float','string','char','bool']) {
      if (line.startsWith(kw+' ')) {
        const rest = line.slice(kw.length+1);
        const parts = rest.split('=');
        const name = parts[0].trim();
        if (parts[1]) {
          const {code:c, result:r} = emit3AC(parts[1].trim(), ir, tmp);
          ir.push(`${name} = ${r}`);
        } else {
          ir.push(`${name} = UNDEF`);
        }
        return;
      }
    }
    if (line.startsWith('if')) {
      const cond = line.match(/\(([^)]+)\)/)?.[1]||'true';
      const {result:r} = emit3AC(cond, ir, tmp);
      ir.push(`if ${r} goto L_then`);
      ir.push(`goto L_else`);
      ir.push(`L_then:`);
    } else if (line.startsWith('while')) {
      const cond = line.match(/\(([^)]+)\)/)?.[1]||'true';
      ir.push(`L_loop:`);
      const {result:r} = emit3AC(cond, ir, tmp);
      ir.push(`ifFalse ${r} goto L_end`);
    } else if (line === '}') {
      if (ir.some(l=>l.includes('L_loop:'))) { ir.push(`goto L_loop`); ir.push(`L_end:`); }
      else { ir.push(`L_else:`); ir.push(`L_exit:`); }
    } else if (line.includes('=') && !line.startsWith('{')) {
      const eqIdx = line.indexOf('=');
      const lhs = line.slice(0,eqIdx).trim();
      const rhs = line.slice(eqIdx+1).trim();
      if (lhs && rhs) {
        const {result:r} = emit3AC(rhs, ir, tmp);
        ir.push(`${lhs} = ${r}`);
      }
    }
  });

  state.ir = ir;

  let html = `<div class="fade-in">`;
  html += `<div style="margin-bottom:10px;color:var(--green);font-size:11px">✓ 3-Address Code generated — ${ir.length} instructions</div>`;
  ir.forEach((inst, i) => {
    const isLabel = inst.endsWith(':');
    const isJump  = inst.startsWith('if') || inst.startsWith('goto') || inst.startsWith('ifFalse');
    html += `<div class="cline">`;
    html += `<span class="cline-num">${String(i).padStart(2,'0')}</span>`;
    if (isLabel)      html += `<span class="cline-label">${esc(inst)}</span>`;
    else if (isJump)  html += `<span class="cline-goto">${esc(inst)}</span>`;
    else              html += `<span>${esc(inst)}</span>`;
    html += `</div>`;
  });
  html += `</div>`;
  document.getElementById('out-ir').innerHTML = html;

  const b = document.getElementById('badge-ir');
  b.textContent = ir.length + ' instr';
  b.style.display = '';
}

function emit3AC(expr, ir, tmp) {
  expr = expr.trim();
  for (const op of ['||','&&','<=','>=','==','!=','<','>','+','-']) {
    const idx = expr.lastIndexOf(op);
    if (idx > 0 && idx < expr.length-op.length) {
      const {result:lr} = emit3AC(expr.slice(0,idx), ir, tmp);
      const {result:rr} = emit3AC(expr.slice(idx+op.length), ir, tmp);
      const t = tmp();
      ir.push(`${t} = ${lr} ${op} ${rr}`);
      return {result:t};
    }
  }
  for (const op of ['*','/']) {
    const idx = expr.lastIndexOf(op);
    if (idx > 0) {
      const {result:lr} = emit3AC(expr.slice(0,idx), ir, tmp);
      const {result:rr} = emit3AC(expr.slice(idx+1), ir, tmp);
      const t = tmp();
      ir.push(`${t} = ${lr} ${op} ${rr}`);
      return {result:t};
    }
  }
  return {result: expr};
}

/* === PHASE 5: OPTIMIZE === */
function doOpt(src, state) {
  const ir = [...(state.ir||[])];
  const opts = [];
  const consts = {};
  const optimized = [];

  ir.forEach(inst => {
    const ca = inst.match(/^([a-zA-Z_]\w*) = (\d+(?:\.\d+)?)$/);
    if (ca) { consts[ca[1]] = +ca[2]; optimized.push({inst, note:null}); return; }

    const binOp = inst.match(/^(t\d+) = ([a-zA-Z0-9_]+) ([+\-*/]) ([a-zA-Z0-9_]+)$/);
    if (binOp) {
      const [,t,a,op,b] = binOp;
      const av = consts[a]!==undefined ? consts[a] : (isNaN(+a) ? null : +a);
      const bv = consts[b]!==undefined ? consts[b] : (isNaN(+b) ? null : +b);

      if (av !== null && bv !== null) {
        const val = op==='+' ? av+bv : op==='-' ? av-bv : op==='*' ? av*bv : bv!==0 ? av/bv : 'inf';
        consts[t] = val;
        optimized.push({inst: `${t} = ${val}`, note:`constant folding (${av} ${op} ${bv} → ${val})`});
        opts.push('constant folding: ' + a + op + b + ' = ' + val);
        return;
      }
      if (op==='+' && (av===0||bv===0)) {
        const other = av===0 ? b : a;
        optimized.push({inst:`${t} = ${other}`, note:'identity: x+0 = x'});
        opts.push('algebraic identity: x + 0 = x');
        return;
      }
      if (op==='*' && (av===1||bv===1)) {
        const other = av===1 ? b : a;
        optimized.push({inst:`${t} = ${other}`, note:'identity: x*1 = x'});
        opts.push('algebraic identity: x * 1 = x');
        return;
      }
      if (op==='*' && (av===0||bv===0)) {
        optimized.push({inst:`${t} = 0`, note:'zero: x*0 = 0'});
        opts.push('zero elimination: x * 0 = 0');
        return;
      }
      const newInst = inst.replace(new RegExp('\\b'+a+'\\b'), av!==null?av:a).replace(new RegExp('\\b'+b+'\\b'), bv!==null?bv:b);
      optimized.push({inst:newInst, note: newInst!==inst?'constant propagation':null});
      if (newInst!==inst) opts.push('constant propagation');
      return;
    }
    optimized.push({inst, note:null});
  });

  if (opts.length===0) opts.push('No further optimizations — code is already optimal');
  state.optimized = optimized;

  let html = `<div class="fade-in">`;
  html += `<div style="margin-bottom:10px;color:var(--amber);font-size:11px">⚡ ${opts.length} optimization(s) applied</div>`;
  html += `<div style="margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid var(--border)">`;
  opts.forEach(o => { html += `<div class="opt-line" style="font-size:11px">→ ${esc(o)}</div>`; });
  html += `</div>`;
  optimized.forEach((item, i) => {
    const isLabel = item.inst.endsWith(':');
    const isJump  = item.inst.startsWith('if')||item.inst.startsWith('goto');
    html += `<div class="cline" style="margin-bottom:1px">`;
    html += `<span class="cline-num">${String(i).padStart(2,'0')}</span>`;
    if (isLabel) html += `<span class="cline-label">${esc(item.inst)}</span>`;
    else if (isJump) html += `<span class="cline-goto">${esc(item.inst)}</span>`;
    else html += `<span>${esc(item.inst)}</span>`;
    if (item.note) html += ` <span style="color:var(--amber);font-size:10px">  ← ${esc(item.note)}</span>`;
    html += `</div>`;
  });
  html += `</div>`;
  document.getElementById('out-opt').innerHTML = html;

  const b = document.getElementById('badge-opt');
  b.textContent = opts.length + ' opt';
  b.style.display = '';
}

/* === PHASE 6: CODE GEN === */
function doCodeGen(src, state) {
  const ir = state.ir||[];
  const asm = [];
  const regMap = {};
  let rc = 0;
  const reg = v => { if(!regMap[v]) regMap[v]='R'+rc++; return regMap[v]; };

  asm.push({ t:'comment', s:'; ═══════════════════════════════════════' });
  asm.push({ t:'comment', s:'; Compiler Design Simulator — Target Code' });
  asm.push({ t:'comment', s:'; Architecture: Pseudo-RISC (register-based)' });
  asm.push({ t:'comment', s:'; ═══════════════════════════════════════' });
  asm.push({ t:'blank' });
  asm.push({ t:'label', s:'SECTION .data' });

  const sym = state.symTable||{};
  Object.entries(sym).forEach(([name,info]) => {
    asm.push({ t:'instr', s:`  ${name.padEnd(12)} DW  0x0000   ; ${info.type}, line ${info.line}` });
  });
  asm.push({ t:'blank' });
  asm.push({ t:'label', s:'SECTION .text' });
  asm.push({ t:'label', s:'MAIN:' });

  ir.forEach(inst => {
    if (inst.endsWith(':')) { asm.push({t:'label', s:inst}); return; }
    if (inst.startsWith('goto')) { asm.push({t:'jump', s:`  JMP   ${inst.slice(5)}`}); return; }
    if (inst.startsWith('ifFalse')) {
      const m = inst.match(/ifFalse (\w+) goto (\w+)/);
      if (m) {
        const r = reg(m[1]);
        asm.push({t:'instr', s:`  LOAD  ${r.padEnd(4)}, ${m[1]}`});
        asm.push({t:'jump',  s:`  JZ    ${r.padEnd(4)}, ${m[2]}`});
      }
      return;
    }
    if (inst.startsWith('if ')) {
      const m = inst.match(/if (\w+) goto (\w+)/);
      if (m) {
        const r = reg(m[1]);
        asm.push({t:'instr', s:`  LOAD  ${r.padEnd(4)}, ${m[1]}`});
        asm.push({t:'jump',  s:`  JNZ   ${r.padEnd(4)}, ${m[2]}`});
      }
      return;
    }
    const assign = inst.match(/^(\w+) = (.+)$/);
    if (assign) {
      const [,dest,rhs] = assign;
      const binOp = rhs.match(/^(\S+) ([+\-*/<>!=]+|&&|\|\|) (\S+)$/);
      if (binOp) {
        const [,a,op,b] = binOp;
        const ra = reg(a), rb = reg(b), rd = reg(dest);
        const opMap = {'+':'ADD','-':'SUB','*':'MUL','/':'DIV','<':'SLT','>':'SGT','==':'SEQ','!=':'SNE','<=':'SLE','>=':'SGE','&&':'AND','||':'OR'};
        asm.push({t:'instr', s:`  LOAD  ${ra.padEnd(4)}, ${a}`});
        asm.push({t:'instr', s:`  LOAD  ${rb.padEnd(4)}, ${b}`});
        asm.push({t:'instr', s:`  ${(opMap[op]||'OP').padEnd(5)} ${rd.padEnd(4)}, ${ra}, ${rb}`});
        asm.push({t:'instr', s:`  STORE ${rd.padEnd(4)}, ${dest}`});
      } else if (rhs === 'UNDEF') {
        asm.push({t:'instr', s:`  MOV   ${reg(dest).padEnd(4)}, #0x0000  ; uninitialized`});
      } else if (/^\d+(\.\d+)?$/.test(rhs)) {
        const rd = reg(dest);
        asm.push({t:'instr', s:`  MOV   ${rd.padEnd(4)}, #${rhs}`});
        asm.push({t:'instr', s:`  STORE ${rd.padEnd(4)}, ${dest}`});
      } else {
        const rs = reg(rhs), rd = reg(dest);
        asm.push({t:'instr', s:`  LOAD  ${rs.padEnd(4)}, ${rhs}`});
        asm.push({t:'instr', s:`  MOV   ${rd.padEnd(4)}, ${rs}`});
        asm.push({t:'instr', s:`  STORE ${rd.padEnd(4)}, ${dest}`});
      }
    }
  });

  asm.push({t:'jump', s:'  HALT'});
  asm.push({t:'blank'});
  asm.push({t:'comment', s:'; Register Allocation Map:'});
  Object.entries(regMap).forEach(([v,r]) => {
    asm.push({t:'comment', s:`;   ${r.padEnd(4)} ← ${v}`});
  });

  let html = `<div class="fade-in">`;
  html += `<div style="margin-bottom:10px;color:var(--green);font-size:11px">✓ Target code generated — ${asm.filter(a=>a.t==='instr'||a.t==='jump').length} instructions, ${Object.keys(regMap).length} registers allocated</div>`;
  asm.forEach(item => {
    if (item.t==='blank') { html += '<br>'; return; }
    html += `<div class="cline">`;
    if (item.t==='comment') html += `<span class="cline-comment">${esc(item.s)}</span>`;
    else if (item.t==='label') html += `<span class="cline-label">${esc(item.s)}</span>`;
    else if (item.t==='jump')  html += `<span class="cline-goto">${esc(item.s)}</span>`;
    else                       html += `<span class="cline-instr">${esc(item.s)}</span>`;
    html += `</div>`;
  });
  html += `</div>`;
  document.getElementById('out-code').innerHTML = html;

  const b = document.getElementById('badge-code');
  b.textContent = Object.keys(regMap).length + ' regs';
  b.style.display = '';
}

/* INIT */
updateLineNums();
document.getElementById('src').addEventListener('scroll', () => {
  document.getElementById('line-nums').scrollTop = document.getElementById('src').scrollTop;
});